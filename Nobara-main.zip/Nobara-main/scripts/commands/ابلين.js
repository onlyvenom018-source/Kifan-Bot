const chalk = require('chalk');
const fs = require('fs-extra');
const path = require('path');
const axios = require('axios');

if (!global.ابلين_mode) {
  global.ابلين_mode = {};
}

// 🔑 المفتاح الجديد من صاحبك
const GEMINI_KEYS = [
  'AQ.Ab8RN6IN7yZgKqH20xM1EqCoBx0k349aLoBeV7iHmQWZwWYWvg'
];

let keyIndex = 0;

module.exports.config = {
  name: "ابلين",
  aliases: ["بوت"],
  version: "25.7.0",
  author: "ياسين",
  countDown: 1,
  adminOnly: false,
  description: "ذكاء اصطناعي جزائࢪي",
  category: "ai",
  guide: "{pn} [سؤال] | اون | اوف",
  usePrefix: false,
};

module.exports.run = async function ({ api, event, args }) {

  const { threadID, messageID, senderID } = event;
  const query = args.join(" ").trim();

  try {

    const isDev =
      senderID === "61578522925662" ||
      senderID === "61586427133824";

    // تشغيل وضع الصوت
    if (query === "اون") {
      global.ابلين_mode[threadID] = "voice_only";
      return api.sendMessage("أبشر.. وضع الصوت 🎤 حيشتغل هسة.", threadID, messageID);
    }

    // إيقاف وضع الصوت
    if (query === "اوف") {
      global.ابلين_mode[threadID] = "text_only";
      return api.sendMessage("خلاص.. قلبنا نص 🤐.", threadID, messageID);
    }

    // إرسال ستيكر لو ما في كلام
    if (!query) {
      const stickers = ["422806808355567", "422806995022215", "422807215022193", "144885579253456", "395015337517600"];
      return api.sendMessage({ sticker: stickers[Math.floor(Math.random() * stickers.length)] }, threadID, messageID);
    }

    api.setMessageReaction(isDev ? "✨" : "🐬", messageID, threadID, (err) => {
      if (err) console.error("Reaction error:", err);
    });

    const response = await askGemini(query);

    const currentMode = global.ابلين_mode[threadID] || "text_only";

    if (currentMode === "voice_only") {
      return handleVoice(api, event, response);
    }

    return api.sendMessage(response, threadID, (err, info) => {
      if (err) return;
      pushReply(info.messageID, senderID);
      api.setMessageReaction("✅", messageID, threadID, (err) => {
        if (err) console.error("Reaction error:", err);
      });
    }, messageID);

  } catch (error) {

    console.log(chalk.red(`[ABLEEN ERROR] ${error.message}`));

    api.setMessageReaction("❌", messageID, threadID, (err) => {
      if (err) console.error("Reaction error:", err);
    });

    return api.sendMessage("السيرفر كبس هسة يا بابا، جرب تاني 🐱", threadID, messageID);
  }
};

module.exports.handleReply = async function ({ api, event, handleReply }) {

  const { threadID, messageID, senderID, body } = event;

  try {

    if (handleReply.author != senderID) return;

    const isDev = senderID === "61578522925662" || senderID === "61586427133824";

    api.setMessageReaction(isDev ? "✨" : "🐬", messageID, threadID, (err) => {
      if (err) console.error("Reaction error:", err);
    });

    const response = await askGemini(body);

    const currentMode = global.ابلين_mode[threadID] || "text_only";

    if (currentMode === "voice_only") {
      return handleVoice(api, event, response);
    }

    return api.sendMessage(response, threadID, (err, info) => {
      if (err) return;
      pushReply(info.messageID, senderID);
      api.setMessageReaction("✅", messageID, threadID, (err) => {
        if (err) console.error("Reaction error:", err);
      });
    }, messageID);

  } catch (error) {

    console.log(chalk.red(`[HANDLE REPLY ERROR] ${error.message}`));

    api.setMessageReaction("❌", messageID, threadID, (err) => {
      if (err) console.error("Reaction error:", err);
    });
  }
};

// =======================
// Gemini Request (باستخدام الرابط الجديد)
// =======================

async function askGemini(query) {

  const key = GEMINI_KEYS[keyIndex % GEMINI_KEYS.length];
  keyIndex++;

  // ✅ الرابط الجديد من صاحبك
  const API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent';

  try {

    const res = await axios.post(
      API_URL,
      {
        contents: [
          {
            parts: [
              {
                text: query
              }
            ]
          }
        ],
        generationConfig: {
          temperature: 0.8,
          maxOutputTokens: 500
        }
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'X-goog-api-key': key
        }
      }
    );

    return res.data?.candidates?.[0]?.content?.parts?.[0]?.text || "حصل خطأ في الاتصال 🤕";

  } catch (error) {

    console.log(chalk.red(`[GEMINI ERROR] ${error.response?.data || error.message}`));

    if (error.response?.status === 404) {
      return "⚠️ المفتاح غير صالح أو منتهي الصلاحية. جدد المفتاح من Google AI Studio.";
    }

    if (error.response?.status === 403) {
      return "⚠️ المفتاح محظور أو ليس لديك صلاحية. تأكد من تفعيل Gemini API.";
    }

    throw error;
  }
}

// =======================
// Voice Handler
// =======================

async function handleVoice(api, event, text) {

  const audioPath = path.resolve(__dirname, "cache", `${event.messageID}.mp3`);

  try {

    const { data } = await axios.get(
      `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(text)}&tl=ar&client=tw-ob`,
      { responseType: "arraybuffer" }
    );

    fs.ensureDirSync(path.join(__dirname, "cache"));
    fs.writeFileSync(audioPath, Buffer.from(data, "utf-8"));

    return api.sendMessage({ attachment: fs.createReadStream(audioPath) }, event.threadID, (err, info) => {
      if (!err) pushReply(info.messageID, event.senderID);
      if (fs.existsSync(audioPath)) fs.unlinkSync(audioPath);
    }, event.messageID);

  } catch (error) {

    if (fs.existsSync(audioPath)) fs.unlinkSync(audioPath);
    return api.sendMessage(text, event.threadID, event.messageID);
  }
}

// =======================
// Push Reply
// =======================

function pushReply(messageID, author) {
  if (!global.client.handleReply) global.client.handleReply = [];
  global.client.handleReply.push({ name: "ابلين", messageID, author });
}