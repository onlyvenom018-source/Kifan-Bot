module.exports.config = {
  name: "لاست",
  aliases: ["list", "groups"],
  version: "1.0",
  author: "ياسين",
  countDown: 5,
  adminOnly: false,
  description: "عرض قائمة المجموعات والخروج منها",
  category: "المطور",
  guide: "{pn} غروب [الرقم]",
  usePrefix: true,
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  const adminUID = "61586427133824";

  try {
    // التحقق من صلاحيات المطور
    if (senderID != adminUID) {
      return api.sendMessage(
        "❌ لا يمكنك استخدام هذا الأمر، هذا الأمر خاص بالمطور فقط.",
        threadID,
        messageID
      );
    }

    // التحقق من وجود args والتعامل معها
    // لاست → args = []
    // لاست غروب 1 → args = ["غروب","1"]
    if (args.length === 0) {
      // عرض قائمة المجموعات
      try {
        api.setMessageReaction("⏳", messageID, () => {}, true);

        const groups = await api.getThreadList(100, null, ["INBOX"]);
        const groupList = groups.filter(g => g.isGroup && g.threadID);

        if (!groupList || groupList.length === 0) {
          return api.sendMessage(
            "⚠️ لا توجد مجموعات.",
            threadID,
            messageID
          );
        }

        let msg = "📋 قائمة المجموعات\n\n";
        
        groupList.forEach((g, i) => {
          msg += `${i + 1} - ${g.name || "بدون اسم"}\n`;
          msg += `🆔 ${g.threadID}\n\n`;
        });

        msg += "💡 للخروج اكتب:\n";
        msg += "لاست غروب 1\n";
        msg += "لاست غروب 2\n";
        msg += "لاست غروب 3\n";
        msg += "...";

        api.sendMessage(msg, threadID, messageID);
        api.setMessageReaction("✅", messageID, () => {}, true);

      } catch (error) {
        console.log("خطأ في عرض قائمة المجموعات:", error);
        api.sendMessage(
          "❌ حدث خطأ أثناء جلب المجموعات.",
          threadID,
          messageID
        );
      }
      
      return;
    }

    // معالجة أمر الخروج من مجموعة محددة
    // التحقق من أن أول عنصر في args هو "غروب" ووجود رقم ثانٍ
    if (args[0] && args[0].toLowerCase() === "غروب" && args[1]) {
      const groupNumber = parseInt(args[1]);
      
      if (isNaN(groupNumber) || groupNumber < 1) {
        return api.sendMessage(
          "❌ رقم المجموعة غير صحيح.",
          threadID,
          messageID
        );
      }

      try {
        // جلب قائمة المجموعات
        const groups = await api.getThreadList(100, null, ["INBOX"]);
        const groupList = groups.filter(g => g.isGroup && g.threadID);

        if (!groupList || groupList.length === 0) {
          return api.sendMessage(
            "⚠️ لا توجد مجموعات.",
            threadID,
            messageID
          );
        }

        if (groupNumber > groupList.length) {
          return api.sendMessage(
            "❌ رقم المجموعة غير صحيح.",
            threadID,
            messageID
          );
        }

        const targetGroup = groupList[groupNumber - 1];
        const groupName = targetGroup.name || "بدون اسم";
        const targetThreadID = targetGroup.threadID;

        // محاولة إرسال رسالة داخل المجموعة قبل الخروج (حتى لو فشلت نكمل)
        try {
          await api.sendMessage(
            "👋 لقد غادر البوت المجموعة.",
            targetThreadID
          );
          console.log(`✅ تم إرسال رسالة الوداع إلى المجموعة: ${groupName} (${targetThreadID})`);
        } catch (sendError) {
          console.log(`⚠️ فشل إرسال رسالة الوداع إلى ${groupName}: ${sendError.message}`);
          // نكمل التنفيذ حتى لو فشل الإرسال
        }

        // الخروج من المجموعة
        const botID = api.getCurrentUserID();
        console.log(`🔄 محاولة الخروج من المجموعة: ${groupName} (${targetThreadID})`);

        api.removeUserFromGroup(
          botID,
          targetThreadID,
          (err) => {
            if (err) {
              console.log(`❌ فشل الخروج من ${groupName}:`, err);
              return api.sendMessage(
                `❌ فشل الخروج من المجموعة: ${err.message || err}`,
                threadID,
                messageID
              );
            }

            console.log(`✅ تم الخروج بنجاح من المجموعة: ${groupName} (${targetThreadID})`);
            
            // إرسال تأكيد نجاح الخروج
            api.sendMessage(
              `✅ تم خروج البوت من:\n${groupName}`,
              threadID,
              messageID
            );
          }
        );

      } catch (error) {
        console.log("❌ خطأ في معالجة الخروج من المجموعة:", error);
        api.sendMessage(
          "❌ حدث خطأ أثناء محاولة الخروج من المجموعة.",
          threadID,
          messageID
        );
      }
      
      return;
    }

    // إذا كانت args غير معروفة أو أمر غير صحيح
    return api.sendMessage(
      "❌ أمر غير صحيح. استخدم:\nلاست - لعرض المجموعات\nلاست غروب [الرقم] - للخروج من مجموعة محددة",
      threadID,
      messageID
    );

  } catch (error) {
    console.log("❌ خطأ رئيسي في الأمر لاست:", error);
    api.sendMessage(
      "❌ حدث خطأ غير متوقع.",
      threadID,
      messageID
    );
  }
};