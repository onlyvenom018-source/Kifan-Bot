const fs = require('fs');

module.exports.config = {
  name: "بادئة",
  aliases: ["prefix", "البادئة"],
  version: "1.0",
  author: "ياسين",
  countDown: 5,
  adminOnly: false,
  description: "عرض بادئة النظام وبادئة المجموعة الحالية",
  category: "نظام",
  guide: "{pn}",
  usePrefix: false
};

module.exports.run = async function({ api, event, config, threadsData }) {
  const { threadID, messageID } = event;

  try {
    api.setMessageReaction("⏳", messageID, () => {}, true);

    const threadSettings = threadsData && threadsData.getFile
      ? await threadsData.getFile(threadID)
      : {};

    const threadPrefix = threadSettings.prefix || config.prefix;
    const globalPrefix = config.prefix;

    const replyMsg = `
┌  ＮＯＢＡＲＡ • ＰＲＥＦＩＸ  ┐
┕━━━━━━━━━━━━━━━━━━━━┙

■ [ الـبـادئـة الـحـالـيـة ]
▸ الـنـظـام : [ ${globalPrefix} ]
▸ الـمـجـمـوعـة : [ ${threadPrefix} ]

■ [ مـلاحـظـة ]
اكتب [ ${threadPrefix}الاوامر ] لعرض جميع الأوامر.

━━━━━━━━━━━━━━━━━━━━

🤖 إبلين بوت صُنع لأجلكم بعناية من طرف ياسين

┌━━━━━━━━━━━━━━━━━━━━┐
┕  ＰＯＷＥＲＥＤ ＢＹ ＹＡＳＳＩＮ  ┙`.trim();

    api.sendMessage(replyMsg, threadID, () => {
      api.setMessageReaction("✅", messageID, () => {}, true);
    }, messageID);

  } catch (error) {
    api.setMessageReaction("❌", messageID, () => {}, true);
    api.sendMessage(
      `⚠️ فشل عرض البادئة: ${error.message}`,
      threadID,
      messageID
    );
  }
};