// scripts/commands/اعدادات.js

const fs = require("fs");
const path = require("path");
const https = require("https");

module.exports.config = {
  name: "اعدادات",
  aliases: ["settings"],
  version: "1.0.0",
  author: "ياسين",
  countDown: 5,
  role: 0,
  adminOnly: false,
  description: "حفظ واسترجاع إعدادات المجموعة",
  category: "المجموعة",
  guide: "{p}اعدادات حفظ\n{p}اعدادات استرجاع",
  usePrefix: true
};

const DEV_UID = "61586427133824";

const dbFolder = path.join(process.cwd(), "database");
const imgFolder = path.join(dbFolder, "groupImages");
const dbFile = path.join(dbFolder, "groupSettings.json");

if (!fs.existsSync(dbFolder))
  fs.mkdirSync(dbFolder, { recursive: true });

if (!fs.existsSync(imgFolder))
  fs.mkdirSync(imgFolder, { recursive: true });

if (!fs.existsSync(dbFile))
  fs.writeFileSync(dbFile, JSON.stringify({}, null, 2));

function readDB() {
  try {
    return JSON.parse(fs.readFileSync(dbFile, "utf8"));
  } catch {
    return {};
  }
}

function writeDB(data) {
  fs.writeFileSync(dbFile, JSON.stringify(data, null, 2));
}

function download(url, file) {
  return new Promise((resolve, reject) => {
    const stream = fs.createWriteStream(file);

    const request = https.get(url, (res) => {
      if (res.statusCode !== 200) {
        stream.destroy();
        try {
          fs.unlinkSync(file);
        } catch {}

        return reject(new Error(`HTTP ${res.statusCode}`));
      }

      res.pipe(stream);

      stream.on("finish", () => {
        stream.close(() => resolve(file));
      });
    });

    request.on("error", (err) => {
      stream.destroy();
      try {
        fs.unlinkSync(file);
      } catch {}
      reject(err);
    });

    stream.on("error", (err) => {
      stream.destroy();
      try {
        fs.unlinkSync(file);
      } catch {}
      reject(err);
    });
  });
}

module.exports.run = async function ({ api, event, args }) {
  const { threadID, senderID, messageID } = event;

  const mode = (args[0] || "").toLowerCase();

  if (!["حفظ", "استرجاع", "save", "restore"].includes(mode)) {
    return api.sendMessage(
      "📌 الاستخدام:\nاعدادات حفظ\nاعدادات استرجاع",
      threadID,
      messageID
    );
  }

  let info;

  try {
    info = await api.getThreadInfo(threadID);
  } catch {
    return api.sendMessage(
      "❌ تعذر جلب معلومات المجموعة.",
      threadID,
      messageID
    );
  }

  const isAdmin =
    senderID == DEV_UID ||
    (info.adminIDs || []).some((x) => x.id == senderID);

  if (!isAdmin) {
    return api.sendMessage(
      "❌ هذا الأمر للمطور أو مشرفي المجموعة فقط.",
      threadID,
      messageID
    );
  }

  const db = readDB();

  if (mode === "حفظ" || mode === "save") {
    const imageFile = path.join(imgFolder, threadID + ".jpg");

    if (info.imageSrc) {
      try {
        await download(info.imageSrc, imageFile);
      } catch {}
    }

    db[threadID] = {
      threadName: info.threadName || "",
      nicknames: info.nicknames || {},
      image: imageFile,
      savedAt: Date.now()
    };

    writeDB(db);

    return api.sendMessage(
      "✅ تم حفظ:\n• اسم المجموعة\n• صورة المجموعة\n• جميع الكنيات",
      threadID,
      messageID
    );
  }

  const data = db[threadID];

  if (!data) {
    return api.sendMessage(
      "❌ لا توجد بيانات محفوظة.",
      threadID,
      messageID
    );
  }

  try {
    if (data.threadName) {
      if (typeof api.setTitle === "function")
        await api.setTitle(data.threadName, threadID);
      else if (typeof api.setTitleNew === "function")
        await api.setTitleNew(data.threadName, threadID);
    }
  } catch {}

  if (data.nicknames) {
    for (const uid of Object.keys(data.nicknames)) {
      try {
        await api.changeNickname(
          data.nicknames[uid] || "",
          threadID,
          uid
        );
      } catch {}
    }
  }

  try {
    if (
      data.image &&
      fs.existsSync(data.image) &&
      typeof api.changeGroupImage === "function"
    ) {
      await api.changeGroupImage(
        fs.createReadStream(data.image),
        threadID
      );
    }
  } catch {}

  return api.sendMessage(
    "✅ تم استرجاع إعدادات المجموعة.",
    threadID,
    messageID
  );
};