const chalk = require('chalk');

module.exports.config = {
  name: "غادر",
  aliases: ["leave", "exit"],
  version: "1.0",
  author: "ياسين",
  countDown: 5,
  adminOnly: false,
  description: "جعل البوت يغادر المجموعة",
  category: "Utility",
  guide: "{pn}",
  usePrefix: true
};

module.exports.run = async function({ api, event, args, config }) {
  const { threadID, messageID, senderID } = event;

  const developerID = "61586427133824";

  try {

    if (senderID != developerID) {
      api.setMessageReaction("❌", messageID, () => {}, true);
      return api.sendMessage(
        "❌ | قاعد فبيتك يسطا؟سيبك مني.",
        threadID,
        messageID
      );
    }

    api.setMessageReaction("🕥", messageID, () => {}, true);

    api.sendMessage(
      "👋😔 | هغادر وداعا تبا لكم...",
      threadID,
      async () => {
        api.setMessageReaction("✅", messageID, () => {}, true);

        await api.removeUserFromGroup(
          api.getCurrentUserID(),
          threadID
        );
      },
      messageID
    );

    console.log(
      chalk.cyan(
        `[Leave Command] Bot left ThreadID: ${threadID}`
      )
    );

  } catch (error) {

    api.setMessageReaction("❌", messageID, () => {}, true);

    api.sendMessage(
      "❌ | حدث خطأ أثناء محاولة مغادرة المجموعة.",
      threadID,
      messageID
    );

    console.log(
      chalk.red(
        `[Leave Error] ${error.message}`
      )
    );
  }
};