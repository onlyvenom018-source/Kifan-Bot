const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "../../database/takrir.json");

const DEV_UID = "61586427133824";

if (!global.lastTakrirHour) {
  global.lastTakrirHour = null;
}

module.exports.config = {
  name: "تذكير",
  aliases: ["takrir", "reminder"],
  version: "1.0.3",
  author: "Yacine",
  countDown: 5,
  role: 0,
  adminOnly: false,
  description: "إرسال التذكيرات التلقائية للمجموعات كل 15 دقيقة",
  category: "المجموعة",
  guide: "{p}تذكير",
  usePrefix: true
};

module.exports.run = async function ({ api, event }) {
  try {
    if (event.senderID !== DEV_UID) {
      return api.sendMessage(
        "❌ هذا الأمر مخصص للمطور فقط.",
        event.threadID,
        event.messageID
      );
    }

    if (global.takrirStarted) {
      return api.sendMessage(
        "✅ نظام التذكير يعمل بالفعل.",
        event.threadID,
        event.messageID
      );
    }

    global.takrirStarted = true;

    if (global.takrirInterval) {
      clearInterval(global.takrirInterval);
    }

    global.takrirInterval = setInterval(async () => {
      try {
        const now = new Date();

        const parts = new Intl.DateTimeFormat("en-GB", {
          timeZone: "Africa/Algiers",
          hour12: false,
          hour: "2-digit",
          minute: "2-digit"
        }).formatToParts(now);

        const hour = Number(parts.find(i => i.type === "hour").value);
        const minute = Number(parts.find(i => i.type === "minute").value);

        // إرسال كل 15 دقيقة فقط
        if (minute % 15 !== 0) return;

        const date = new Intl.DateTimeFormat("en-CA", {
          timeZone: "Africa/Algiers"
        }).format(now);

        // منع التكرار بنفس الربع ساعة
        const hourKey = `${date}-${hour}-${minute}`;

        if (global.lastTakrirHour === hourKey) return;
        global.lastTakrirHour = hourKey;

        if (!fs.existsSync(DB_PATH)) return;

        let data;

        try {
          data = JSON.parse(fs.readFileSync(DB_PATH, "utf8"));
        } catch (err) {
          console.error("[TAKRIR JSON ERROR]", err);
          return;
        }

        if (!Array.isArray(data) || data.length === 0) return;

        const groups = [...new Set(
          data.map(item =>
            typeof item === "string"
              ? item
              : item.threadID || item.id || item.groupID
          ).filter(Boolean)
        )];

        if (groups.length === 0) return;

        let message;

        if (hour === 6 && minute === 0) {
          message = "🌅 صباح الخير.";
        } else if (hour === 12 && minute === 0) {
          message = "☀️ مساء الخير.";
        } else if (hour === 18 && minute === 0) {
          message = "🌇 مساء الخير.";
        } else if (hour === 0 && minute === 0) {
          message = "🌙 تصبحون على خير.";
        } else {
          message = "🔔 تذكير عادي.";
        }

        for (const threadID of groups) {
          try {
            await api.sendMessage(message, threadID);
          } catch (err) {
            console.error(
              `[TAKRIR SEND ERROR ${threadID}]`,
              err
            );
          }
        }

      } catch (err) {
        console.error("[TAKRIR LOOP ERROR]", err);
      }

    }, 60000);

    return api.sendMessage(
      "✅ تم تشغيل نظام التذكير كل 15 دقيقة.",
      event.threadID,
      event.messageID
    );

  } catch (err) {
    console.error("[TAKRIR START ERROR]", err);
  }
};