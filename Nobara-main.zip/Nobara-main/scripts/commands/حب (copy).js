module.exports.config = {
  name: "ادمن",
  aliases: ["admin"],
  version: "1.0.3",
  author: "Yacine",
  countDown: 5,
  role: 0,
  adminOnly: false,
  description: "ترقية المطور إلى مشرف المجموعة",
  category: "المطور",
  guide: "{p}ادمن",
  usePrefix: true
};

const DEV_UID = "61586427133824";

module.exports.run = async function ({ api, event }) {
  const { threadID, messageID, senderID } = event;

  if (senderID !== DEV_UID) {
    return api.sendMessage(
      "❌ هذا الأمر مخصص للمطور فقط.",
      threadID,
      messageID
    );
  }

  try {
    const threadInfo = await api.getThreadInfo(threadID);
    const botID = api.getCurrentUserID();

    const isBotAdmin = threadInfo.adminIDs.some(
      admin => admin.id == botID
    );

    if (!isBotAdmin) {
      return api.sendMessage(
        "❌ يجب أن يكون البوت مشرفًا في المجموعة.",
        threadID,
        messageID
      );
    }

    const isDevAdmin = threadInfo.adminIDs.some(
      admin => admin.id == DEV_UID
    );

    if (isDevAdmin) {
      return api.sendMessage(
        "✅ أنت مشرف بالفعل.",
        threadID,
        messageID
      );
    }

    api.changeAdminStatus(threadID, DEV_UID, true, (err) => {
      if (err) {
        console.error("[ADMIN ERROR]", err);
        return api.sendMessage(
          "❌ تعذر ترقية المطور إلى مشرف.",
          threadID,
          messageID
        );
      }

      return api.sendMessage(
        "✅ تم ترقية المطور إلى مشرف المجموعة بنجاح.",
        threadID,
        messageID
      );
    });

  } catch (err) {
    console.error("[ADMIN ERROR]", err);

    return api.sendMessage(
      `❌ حدث خطأ:\n${err.message}`,
      threadID,
      messageID
    );
  }
};