module.exports = {
  config: {
    name: "help",
    aliases: ["الاوامر", "أوامر", "اوامر", "المساعدة"],
    version: "2.0.0",
    author: "ياسين",
    countDown: 5,
    role: 0,
    usePrefix: true,
    description: "يعرض قائمة الأوامر أو تفاصيل أمر معين.",
    category: "system",
    guide: "{p}help [command]"
  },

  run: async ({ api, event, args, config }) => {
    const { threadID, messageID } = event;

    const prefix = config.prefix || "/";
    const allCommands = global.commands || new Map();

    if (allCommands.size === 0) {
      return api.sendMessage(
        "⚠️ لا توجد أوامر محملة حالياً.",
        threadID,
        messageID
      );
    }

    // معلومات أمر معين
    if (args[0]) {
      const name = args[0].toLowerCase();

      const command =
        allCommands.get(name) ||
        [...allCommands.values()].find(cmd =>
          cmd.config?.aliases?.includes(name)
        );

      if (!command) {
        return api.sendMessage(
          `❌ الأمر "${name}" غير موجود.`,
          threadID,
          messageID
        );
      }

      const c = command.config;

      let msg = "";
      msg += "╔════════『 📖 معلومات الأمر 』════════╗\n\n";
      msg += `📌 الاسم : ${c.name}\n`;
      msg += `📝 الوصف : ${c.description || "لا يوجد"}\n`;
      msg += `🔄 الإصدار : ${c.version || "1.0.0"}\n`;
      msg += `👤 المطور : ${c.author || "غير معروف"}\n`;
      msg += `👑 الصلاحية : ${c.role || 0}\n`;
      msg += `⚙️ يحتاج بادئة : ${c.usePrefix ? "نعم" : "لا"}\n`;

      if (c.aliases?.length) {
        msg += `🔗 الأسماء البديلة : ${c.aliases.join(", ")}\n`;
      }

      msg += `📖 الاستخدام : ${
        c.guide
          ? c.guide.replace("{p}", prefix).replace("{pn}", prefix + c.name + " ")
          : prefix + c.name
      }\n\n`;

      msg += "━━━━━━━━━━━━━━━━━━━━━━\n";
      msg += "🤖 Eblin Bot صُنع لأجلكم بعناية\n";
      msg += "👨‍💻 تطوير: ياسين";

      return api.sendMessage(msg, threadID, messageID);
    }

    // قائمة الأوامر
    let list = [];

    allCommands.forEach(cmd => {
      list.push(`❖ ${cmd.config.name}`);
    });

    let msg = "";
    msg += "╔════════『 🤖 EBLIN BOT 🤖 』════════╗\n\n";
    msg += "        ⚡ مركز أوامر إبلين بوت ⚡\n";
    msg += "      جميع أوامر البوت في مكان واحد\n\n";
    msg += "╚════════════════════════════════════╝\n\n";

    msg += "╭────── 📊 معلومات البوت ──────╮\n";
    msg += `│ 👨‍💻 المطور : ياسين\n`;
    msg += `│ 📊 عدد الأوامر : ${allCommands.size}\n`;
    msg += `│ ⚙️ البادئة : ${prefix}\n`;
    msg += "╰──────────────────────────────╯\n\n";

    msg += "🔗 حساب المطور:\n";
    msg += "https://www.facebook.com/profile.php?id=61586427133824\n\n";

    msg += "━━━━━━━━━━━━━━━━━━━━━━\n";
    msg += "📜 قائمة الأوامر\n";
    msg += "━━━━━━━━━━━━━━━━━━━━━━\n\n";

    msg += list.join("\n");
    msg += "\n\n━━━━━━━━━━━━━━━━━━━━━━\n";
    msg += `💡 لمعرفة تفاصيل أي أمر:\n${prefix}help [اسم الأمر]\n`;
    msg += "━━━━━━━━━━━━━━━━━━━━━━\n\n";

    msg += "🤖 Eblin Bot صُنع لأجلكم بعناية\n";
    msg += "💚 شكراً لاستخدامكم البوت\n";
    msg += "👨‍💻 تطوير: ياسين";

    api.sendMessage(msg, threadID, messageID);
  }
};