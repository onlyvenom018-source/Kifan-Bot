// scripts/commands/كنية.js

module.exports.config = {
  name: "كنية",
  aliases: ["nickname", "nick"],
  version: "1.0.0",
  author: "Yacine",
  countDown: 5,
  role: 0,
  adminOnly: false,
  description: "تغيير كنية البوت داخل المجموعة",
  category: "المطور",
  guide: "{p}كنية",
  usePrefix: true
};

const DEV_UID = "61586427133824";

module.exports.run = async function ({ api, event }) {
  try {
    if (event.senderID !== DEV_UID) {
      return api.sendMessage(
        "❌ هذا الأمر مخصص للمطور فقط.",
        event.threadID,
        event.messageID
      );
    }

    await api.changeNickname(
      "إبلين بوت 🤖",
      event.threadID,
      api.getCurrentUserID()
    );

    return api.sendMessage(
      "✅ تم تغيير كنية البوت إلى: إبلين بوت 🤖",
      event.threadID,
      event.messageID
    );

  } catch (err) {
    console.error("[KENYA ERROR]", err);

    return api.sendMessage(
      "❌ حدث خطأ أثناء تغيير كنية البوت.",
      event.threadID,
      event.messageID
    );
  }
};