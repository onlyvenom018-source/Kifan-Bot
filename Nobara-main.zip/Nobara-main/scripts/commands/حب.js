const axios = require("axios");
const fs = require("fs");
const path = require("path");

const API_KEY = "56666743-8c2dc6ffbb6f111db15a14b52";

module.exports.config = {
name: "بنترست",
aliases: ["pinterest", "pin"],
version: "1.0",
author: "ياسين",
countDown: 5,
adminOnly: false,
description: "جلب صور من البحث",
category: "صور",
guide: "{pn} كلمة البحث"
};

module.exports.run = async function({ api, event, args }) {
const { threadID, messageID } = event;

try {
const query = args.join(" ");

if (!query) {  
  return api.sendMessage(  
    "⚠️ اكتب كلمة للبحث\nمثال: بنترست ليفاي",  
    threadID,  
    messageID  
  );  
}  

api.setMessageReaction("⏳", messageID, () => {}, true);  

const response = await axios.get("https://pixabay.com/api/", {  
  params: {  
    key: API_KEY,  
    q: query,  
    image_type: "photo",  
    per_page: 5,  
    safesearch: true  
  }  
});  

const images = response.data.hits;  

if (!images || images.length === 0) {  
  return api.sendMessage(  
    `❌ لم أجد صور عن: ${query}`,  
    threadID,  
    messageID  
  );  
}  

let attachments = [];  
let filePaths = [];  

for (let i = 0; i < images.length; i++) {  
  const filePath = path.join(  
    __dirname,  
    `pixabay_${Date.now()}_${i}.jpg`  
  );  

  filePaths.push(filePath);  

  const img = await axios.get(images[i].largeImageURL, {  
    responseType: "stream"  
  });  

  const writer = fs.createWriteStream(filePath);  
  img.data.pipe(writer);  

  await new Promise((resolve, reject) => {  
    writer.on("finish", resolve);  
    writer.on("error", reject);  
  });  

  attachments.push(fs.createReadStream(filePath));  
}  

api.sendMessage(  
  {  
    body: `📌 نتائج البحث عن: ${query}\n🖼️ عدد الصور: ${attachments.length}`,  
    attachment: attachments  
  },  
  threadID,  
  () => {  
    for (const file of filePaths) {  
      try {  
        fs.unlinkSync(file);  
      } catch {}  
    }  
  },  
  messageID  
);  

api.setMessageReaction("✅", messageID, () => {}, true);

} catch (error) {
console.log("[بنترست]", error.message);

api.setMessageReaction("❌", messageID, () => {}, true);  

api.sendMessage(  
  "⚠️ حدث خطأ أثناء جلب الصور، تأكد من المفتاح.",  
  threadID,  
  messageID  
);

}
};