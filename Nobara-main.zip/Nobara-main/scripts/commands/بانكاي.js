const chalk = require("chalk");

const DEV_UID = "61586427133824";

module.exports.config = {
  name: "بانكاي",
  aliases: ["kick", "طرد"],
  version: "1.1",
  author: "ياسين",
  countDown: 5,
  adminOnly: false,
  description: "طرد عضو باستخدام الرد أو التاغ",
  category: "إدارة",
  guide: "{pn} @منشن أو الرد على رسالة",
  usePrefix: true,
};

module.exports.run = async function ({ api, event }) {
  const { threadID, messageID, senderID, mentions, messageReply } = event;

  try {
    api.setMessageReaction("⏳", messageID, () => {}, true);

    const threadInfo = await api.getThreadInfo(threadID);

    const isDeveloper = senderID == DEV_UID;

    const isAdmin =
      isDeveloper ||
      threadInfo.adminIDs.some(admin => admin.id == senderID);

    if (!isAdmin) {
      api.setMessageReaction("❌", messageID, () => {}, true);

      return api.sendMessage(
        "⚠️ هذا الأمر للأدمن فقط يافلاح.",
        threadID,
        messageID
      );
    }

    let targetID;

    if (Object.keys(mentions).length > 0) {
      targetID = Object.keys(mentions)[0];
    } else if (messageReply) {
      targetID = messageReply.senderID;
    } else {
      api.setMessageReaction("❌", messageID, () => {}, true);

      return api.sendMessage(
        "⚠️ اعمل منشن أو رد على الشخص لطرده.",
        threadID,
        messageID
      );
    }

    // حماية المطور
    if (targetID == DEV_UID) {
      api.setMessageReaction("❌", messageID, () => {}, true);

      return api.sendMessage(
        "🚫 لا يمكنك طرد مطوري يافلاح.",
        threadID,
        messageID
      );
    }

    const targetIsAdmin = threadInfo.adminIDs.some(
      admin => admin.id == targetID
    );

    // الأدمن العادي لا يطرد أدمن
    if (targetIsAdmin && !isDeveloper) {
      api.setMessageReaction("❌", messageID, () => {}, true);

      return api.sendMessage(
        "⚠️ لا تستطيع طرد أدمن يافلاح.",
        threadID,
        messageID
      );
    }

    api.removeUserFromGroup(targetID, threadID, err => {
      if (err) {
        api.setMessageReaction("❌", messageID, () => {}, true);

        return api.sendMessage(
          "⚠️ ما قدرتش نطرد العضو.\nتأكد إن البوت أدمن.",
          threadID,
          messageID
        );
      }

      api.setMessageReaction("✅", messageID, () => {}, true);

      return api.sendMessage(
        "تم تنفيذ حكم الإعدام 🤖.\n💃 لقد كان رقاصة.",
        threadID,
        messageID
      );
    });

  } catch (error) {
    console.log(chalk.red(`[Bankai Error] ${error.message}`));

    api.setMessageReaction("❌", messageID, () => {}, true);

    api.sendMessage(
      "⚠️ حدث خطأ في النظام.",
      threadID,
      messageID
    );
  }
};