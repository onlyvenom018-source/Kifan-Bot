const chalk = require('chalk');

module.exports.config = {
  name: "معلومات",
  aliases: ["info", "admin", "سيرفر"],
  version: "1.0",
  author: "ياسين",
  countDown: 5,
  adminOnly: false,
  description: "عرض معلومات البوت والمطور",
  category: "نظام",
  guide: "{pn}",
  usePrefix: true
};

module.exports.run = async function ({ api, event, config }) {
  const { threadID, messageID } = event;

  try {
    api.setMessageReaction("⏳", messageID, () => {}, true);

    const now = new Date();

    const dateStr = now.toLocaleDateString("ar-DZ", {
      timeZone: "Africa/Algiers",
      year: "numeric",
      month: "long",
      day: "numeric"
    });

    const timeStr = now.toLocaleTimeString("ar-DZ", {
      timeZone: "Africa/Algiers",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: true
    });

    const response = `
┏━━━━━━━━━━━━━━━━━━━━━━┓
      『 𝗡𝗢𝗕𝗔𝗥𝗔 𝗜𝗡𝗙𝗢 』
┗━━━━━━━━━━━━━━━━━━━━━━┛

◈【 معلومات المطور 】
✦ الاسم : ياسين (YACINE)
✦ العمر : 20 سنة
✦ الدولة : الجزائر 🇩🇿

◈【 معلومات البوت 】
✦ الاسم : ${config.botName || "Nobara"}
✦ البادئة : ${config.prefix}
✦ التاريخ : ${dateStr}
✦ الوقت : ${timeStr}

◈【 التواصل 】
✦ فيسبوك :
https://www.facebook.com/profile.php?id=61586427133824

✦ تيليجرام :
@yacindj5

━━━━━━━━━━━━━━━━━━━━━━
        POWERED BY YACINE
━━━━━━━━━━━━━━━━━━━━━━`;

    api.sendMessage(response, threadID, () => {
      api.setMessageReaction("✅", messageID, () => {}, true);
    }, messageID);

    console.log(chalk.green("[INFO] Command executed successfully."));
  } catch (err) {
    console.log(chalk.red(err));
    api.setMessageReaction("❌", messageID, () => {}, true);
    api.sendMessage("❌ حدث خطأ أثناء جلب المعلومات.", threadID, messageID);
  }
};