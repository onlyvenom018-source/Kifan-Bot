const chalk = require("chalk");
const axios = require("axios");

module.exports.config = {
  name: "بااع",
  aliases: ["ai", "ذكاء"],
  version: "1.4",
  author: "ياسين",
  countDown: 2,
  adminOnly: false,
  description: "ذكاء اصطناعي سريع جداً",
  category: "ai",
  guide: "{pn} [سؤال]",
  usePrefix: true,
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  const query = args.join(" ").trim();

  try {

    // إذا كتب /بااع فقط
    if (!query) {
      return api.sendMessage(
        "باااع انت فرس نهر 🦛.",
        threadID,
        messageID
      );
    }

    // إذا كتب /بااع ويسو
    if (query.toLowerCase() === "ويسو") {
      return api.sendMessage(
        "باااع انت فرس نهر 🦛.",
        threadID,
        messageID
      );
    }

    api.setMessageReaction("⏳", messageID, threadID, () => {});

    const res = await axios.get(
      `https://text.pollinations.ai/${encodeURIComponent(query)}?model=openai`
    );

    api.sendMessage(
      res.data,
      threadID,
      () => {
        api.setMessageReaction("✅", messageID, threadID, () => {});
      },
      messageID
    );

  } catch (error) {

    api.setMessageReaction("❌", messageID, threadID, () => {});

    api.sendMessage(
      "⚠️ صرا مشكل في الـ API.",
      threadID,
      messageID
    );

    console.log(chalk.red(`[AI ERROR] ${error.message}`));
  }
};

module.exports.handleReply = async function ({ api, event, handleReply }) {
  const { threadID, messageID, senderID, body } = event;

  try {

    if (senderID != handleReply.author) return;

    const query = body.trim();

    // إذا رد عليه بكلمة ويسو
    if (query.toLowerCase() === "ويسو") {
      return api.sendMessage(
        "باااع انت فرس نهر 🦛.",
        threadID,
        messageID
      );
    }

    api.setMessageReaction("⏳", messageID, threadID, () => {});

    const res = await axios.get(
      `https://text.pollinations.ai/${encodeURIComponent(query)}?model=openai`
    );

    api.sendMessage(
      res.data,
      threadID,
      () => {
        api.setMessageReaction("✅", messageID, threadID, () => {});
      },
      messageID
    );

  } catch (error) {

    api.setMessageReaction("❌", messageID, threadID, () => {});

    api.sendMessage(
      "⚠️ حدث خطأ أثناء الرد.",
      threadID,
      messageID
    );

    console.log(chalk.red(`[HANDLE REPLY ERROR] ${error.message}`));
  }
};