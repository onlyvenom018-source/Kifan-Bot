module.exports = {
  config: {
    name: "فيلق",
    aliases: ["الاستطلاع"],
    version: "5.0",
    author: "ياسين",
    countDown: 3,
    role: 0,
    adminOnly: false,
    usePrefix: true,
    description: "دليل أعضاء فيلق الاستطلاع",
    category: "معلومات",
    guide: "{pn}فيلق [اسم العضو | قائمة الأعضاء | عدد الأعضاء]"
  },

  run: async function ({ api, event, args }) {
    const { threadID, messageID } = event;

    const members = [
      {code:"02000000B",name:"عبدو",role:"👑 المؤسس",country:"🇱🇧 لبنان"},
      {code:"1147-02",name:"ياسين",role:"🎖️ قائد الأكاديمية",country:"🇩🇿 الجزائر"},
      {code:"1-02",name:"إلياس",role:"⚔️ قائد الفريق",country:"🇩🇿 الجزائر"},
      {code:"2-02",name:"نادر",role:"🛡️ نائب الفريق",country:"🇹🇳 تونس"},
      {code:"1150-02",name:"لوكي",role:"⭐ ملازم أول",country:"🇪🇬 مصر"},
      {code:"496-02",name:"أياتو",role:"👤 عضو عادي",country:"🇵🇸 فلسطين"},
      {code:"1148-01",name:"محمد",role:"👤 عضو عادي",country:"🇩🇿 الجزائر"},
      {code:"1157-02",name:"سيدو",role:"👤 عضو عادي",country:"🇩🇿 الجزائر"},
      {code:"706-02",name:"ياسر",role:"👤 عضو عادي",country:"🇩🇿 الجزائر"},
      {code:"1139-02",name:"فلاش",role:"👤 عضو عادي",country:"🇪🇬 مصر"},
      {code:"577-02",name:"سامح",role:"👤 عضو عادي",country:"🇪🇬 مصر"},
      {code:"1149-02",name:"أليسا",role:"👤 عضوة عادية",country:"🇲🇦 المغرب"},
      {code:"1133-02",name:"سيليا",role:"💰 مسؤول مالي",country:"🇪🇬 مصر"},
      {code:"1144-02",name:"كاسترو",role:"👤 عضو عادي",country:"🇲🇦 المغرب"},
      {code:"03-02",name:"مارتن",role:"👤 عضو عادي",country:"🇱🇧 لبنان"},
      {code:"1107-02",name:"إياد",role:"👤 عضو عادي",country:"🇮🇶 العراق"},
      {code:"1156-02",name:"موح",role:"👤 عضو عادي",country:"🇩🇿 الجزائر"},
      {code:"915-02",name:"عمر",role:"👤 عضو عادي",country:"🇪🇬 مصر"},
      {code:"1154-02",name:"سجاد",role:"👤 عضو عادي",country:"🇩🇿 الجزائر"},
      {code:"1123-02",name:"شيري",role:"👤 عضوة عادية",country:"🇸🇴 الصومال"},
      {code:"1151-02",name:"طارق",role:"👤 عضو عادي",country:"🇩🇿 الجزائر"},
      {code:"1124-02",name:"ليو",role:"👤 عضو عادي",country:"🇲🇦 المغرب"},
      {code:"1138-02",name:"ويليام",role:"👤 عضو عادي",country:"🇩🇿 الجزائر"},
      {code:"243-02",name:"ريم",role:"👤 عضوة عادية",country:"🇪🇬 مصر"},
      {code:"579-02",name:"فارس",role:"👤 عضو عادي",country:"🇲🇷 موريتانيا"},
      {code:"1121-02",name:"سعدبوه",role:"👤 عضو عادي",country:"🇲🇷 موريتانيا"},
      {code:"293-02",name:"فيونا",role:"👤 عضوة عادية",country:"🇸🇴 الصومال"},
      {code:"BOT-001",name:"إيبلين بوت",role:"🤖 النظام",country:"🌐 افتراضي"}
    ];

    const text = args.join(" ").trim();

    if (!text) {
      return api.sendMessage(
`╭━━〔 🛡️ فيلق الإستطلاع 〕━━╮

🔎 للبحث:
/فيلق ياسين

📋 القائمة:
/فيلق قائمة الأعضاء

📊 العدد:
/فيلق عدد الأعضاء

╰━━━━━━━━━━━━━━━━━━╯`,
threadID,messageID);
    }

    if (text === "عدد الأعضاء") {
      return api.sendMessage(
`╭━━〔 📊 الإحصائيات 〕━━╮

👥 عدد الأعضاء: ${members.length}

╰━━━━━━━━━━━━━━━━━━╯`,
threadID,messageID);
    }

    if (text === "قائمة الأعضاء") {
      let msg = "╭━━〔 📋 قائمة أعضاء فيلق الإستطلاع 〕━━╮\n\n";

      members.forEach((m,i)=>{
        msg += 
`🔹 ${i+1}

👤 الاسم: ${m.name}
🆔 الكود: ${m.code}
🎖️ المنصب: ${m.role}
🌍 الدولة: ${m.country}

ــــــــــــــــــــ

`;
      });

      msg += `👥 المجموع: ${members.length}\n╰━━━━━━━━━━━━━━━━━━╯`;

      return api.sendMessage(msg,threadID,messageID);
    }

    const search = text.toLowerCase();

    const member = members.find(m =>
      m.name.toLowerCase() === search ||
      m.code.toLowerCase() === search
    );

    if (!member) {
      return api.sendMessage(
"❌ العضو غير موجود في السجل.",
threadID,messageID);
    }

    return api.sendMessage(
`╭━━〔 👤 بطاقة العضو 〕━━╮

👤 الاسم: ${member.name}
🆔 الكود: ${member.code}
🎖️ المنصب: ${member.role}
🌍 الدولة: ${member.country}

╰━━━━━━━━━━━━━━━━━━╯`,
threadID,messageID);
  }
};