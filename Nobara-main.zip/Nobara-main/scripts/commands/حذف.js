module.exports = {
  config: {
    name: "حذف",
    aliases: ["delete", "مسح"],
    version: "1.0",
    author: "Henry Lawson",
    countDown: 5,
    role: 2,
    adminOnly: true,
    description: "حذف رسالة البوت بالرد عليها",
    category: "utility",
    guide: "{pn} (رد على رسالة البوت)",
    usePrefix: true
  },

  run: async function ({ api, event, args, config }) {
    const { threadID, messageID, senderID, messageReply } = event;

    if (!messageReply) {
      return api.sendMessage(
        "⚠️ يرجى الرد على رسالة البوت التي تريد حذفها.",
        threadID,
        messageID
      );
    }

    const targetMsgID = messageReply.messageID?.trim();
    if (!targetMsgID) {
      return api.sendMessage(
        "⚠️ لم يتم العثور على معرف الرسالة.",
        threadID,
        messageID
      );
    }

    api.unsendMessage(targetMsgID, (err) => {
      if (!err) {
        console.log(`✅ تم حذف رسالة البوت: ${targetMsgID}`);
        api.sendMessage(
          "🗑️ تم حذف الرسالة!",
          threadID,
          (err2, info) => {
            if (!err2 && info) {
              setTimeout(() => {
                api.unsendMessage(info.messageID, threadID, () => {});
              }, 3000);
            }
          }
        );
      } else {
        console.error("❌ فشل حذف رسالة البوت:", err);
        api.editMessage("🗑️", targetMsgID, (editErr) => {
          if (editErr) {
            api.sendMessage(
              "😢 ما قدرت أحذف الرسالة. ممكن تكون قديمة جداً.",
              threadID,
              messageID
            );
          } else {
            console.log("✅ تم تعديل الرسالة إلى 🗑️");
            api.sendMessage(
              "✅ تم تعديل الرسالة إلى 🗑️ بدلاً من الحذف.",
              threadID,
              messageID
            );
          }
        });
      }
    });
  }
};
